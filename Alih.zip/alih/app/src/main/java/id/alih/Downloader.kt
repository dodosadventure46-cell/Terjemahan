package id.alih

import android.content.ContentValues
import android.content.Context
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.util.concurrent.Executors

typealias Sink = (line: String, replace: Boolean) -> Unit

object Downloader {
    private const val PID = "vardex"
    private val exec = Executors.newSingleThreadExecutor()
    private var ready = false

    @Volatile var busy = false
        private set

    fun videoArgs(url: String, height: Int = 1080) = listOf(
        url, "--no-playlist", "-f", "bv*+ba/b",
        "-S", "res:$height,ext:mp4:m4a", "--merge-output-format", "mp4"
    )

    fun audioArgs(url: String) = listOf(
        url, "--no-playlist", "-f", "ba/b", "-x", "--audio-format", "mp3"
    )

    private var updated = false

    private fun ensure(app: Context, out: Sink, autoUpdate: Boolean = true) {
        if (!ready) {
            out("Menyiapkan yt-dlp, pertama kali butuh beberapa detik...", false)
            YoutubeDL.getInstance().init(app)
            FFmpeg.getInstance().init(app)
            ready = true
        }
        if (autoUpdate && !updated) {
            updated = true
            out("Memperbarui yt-dlp ke versi terbaru...", false)
            try {
                val s = YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.STABLE)
                out("yt-dlp: ${s ?: "diperbarui"}", false)
            } catch (e: Throwable) {
                out("Pembaruan dilewati: " + (e.message ?: "tanpa internet?").trim().take(120), false)
            }
        }
    }

    private fun request(args: List<String>, tmp: File): YoutubeDLRequest {
        val req = YoutubeDLRequest(args.filter { it.startsWith("http", true) })
        req.addOption("-o", tmp.absolutePath + "/%(title).80s [%(id)s].%(ext)s")
        val rest = args.filter { !it.startsWith("http", true) }
        var i = 0
        while (i < rest.size) {
            val t = rest[i]
            val next = rest.getOrNull(i + 1)
            if (t.startsWith("-") && next != null && !next.startsWith("-")) {
                req.addOption(t, next)
                i += 2
            } else {
                req.addOption(t)
                i += 1
            }
        }
        return req
    }

    fun start(ctx: Context, args: List<String>, out: Sink, done: (Boolean) -> Unit = {}) {
        if (busy) {
            out("Masih ada proses berjalan. Ketik stop untuk membatalkan.", false)
            done(false)
            return
        }
        busy = true
        val app = ctx.applicationContext
        exec.execute {
            var ok = false
            var forbidden = false
            val tmp = File(app.getExternalFilesDir(null) ?: app.cacheDir, "tmp")
            try {
                tmp.deleteRecursively()
                tmp.mkdirs()
                ensure(app, out)
                var lastProgress = false
                val cb: (Float, Long, String) -> Unit = { _, _, line ->
                    val t = line.trim()
                    if (t.isNotEmpty()) {
                        if (t.contains("403")) forbidden = true
                        val p =t.startsWith("[download]") && t.contains("%")
                        out(t, p && lastProgress)
                        lastProgress = p
                    }
                }
                YoutubeDL.getInstance().execute(request(args, tmp), PID, true, cb)
                val n = save(app, tmp, out)
                out(
                    if (n > 0) "Selesai. $n file di Download/VarDeX"
                    else "Selesai, tapi tidak ada file hasil.",
                    false
                )
                ok = n > 0
            } catch (e: Throwable) {
                val m = (e.message ?: "").trim().take(300)
                out("Gagal. " + m.ifEmpty { "Lihat pesan ERROR di atas." }, false)
                if (forbidden || m.contains("403")) {
                    out("YouTube menolak (403). Ketik: update nightly, lalu coba lagi.", false)
                }
            } finally {
                tmp.deleteRecursively()
                busy = false
            }
            done(ok)
        }
    }

    fun update(ctx: Context, nightly: Boolean, out: Sink) {
        if (busy) {
            out("Masih ada proses berjalan.", false)
            return
        }
        busy = true
        val app = ctx.applicationContext
        exec.execute {
            try {
                ensure(app, out, false)
                updated = true
                out("Memperbarui yt-dlp (${if (nightly) "nightly" else "stable"})...", false)
                val ch = if (nightly) YoutubeDL.UpdateChannel.NIGHTLY else YoutubeDL.UpdateChannel.STABLE
                val s = YoutubeDL.getInstance().updateYoutubeDL(app, ch)
                out("Pembaruan: ${s ?: "selesai"}", false)
            } catch (e: Throwable) {
                out("Gagal: " + (e.message ?: e.javaClass.simpleName).trim().take(300), false)
            } finally {
                busy = false
            }
        }
    }

    fun stop(out: Sink) {
        try {
            val ok = YoutubeDL.getInstance().destroyProcessById(PID)
            out(if (ok) "Dibatalkan." else "Tidak ada proses berjalan.", false)
        } catch (e: Throwable) {
            out("Tidak ada proses berjalan.", false)
        }
    }

    private fun save(app: Context, tmp: File, out: Sink): Int {
        var n = 0
        val skip = listOf(".part", ".ytdl", ".temp")
        tmp.listFiles()
            ?.filter { f -> f.isFile && skip.none { f.name.endsWith(it) } }
            ?.forEach { f ->
                val mime = MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"
                val cv = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, f.name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, "Download/VarDeX")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val res = app.contentResolver
                val uri = res.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return@forEach
                res.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                cv.clear()
                cv.put(MediaStore.Downloads.IS_PENDING, 0)
                res.update(uri, cv, null, null)
                out("Tersimpan: Download/VarDeX/${f.name}", false)
                n++
            }
        return n
    }
}
