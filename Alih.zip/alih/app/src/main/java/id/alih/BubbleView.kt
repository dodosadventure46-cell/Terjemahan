package id.alih

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View

class BubbleView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.INK }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.AMBER
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * d
    }
    private val glyph = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.PAPER
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
    }
    private val arrow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.AMBER
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 2.5f * d
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val r = w / 2f
        val rr = r - ring.strokeWidth
        c.drawCircle(r, r, rr, fill)
        c.drawCircle(r, r, rr, ring)
        glyph.textSize = w * 0.46f
        c.drawText("A", r, w * 0.58f, glyph)
        val y = w * 0.76f
        c.drawLine(w * 0.32f, y, w * 0.68f, y, arrow)
        c.drawLine(w * 0.68f, y, w * 0.60f, y - w * 0.06f, arrow)
        c.drawLine(w * 0.68f, y, w * 0.60f, y + w * 0.06f, arrow)
    }
}
