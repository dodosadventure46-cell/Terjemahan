package id.alih

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.TextView

object Ui {
    const val INK = 0xFF14161A.toInt()
    const val RAISED = 0xFF1D2026.toInt()
    const val LINE = 0xFF2C3037.toInt()
    const val PAPER = 0xFFECE8DF.toInt()
    const val MUTED = 0xFF8D929B.toInt()
    const val AMBER = 0xFFF2B134.toInt()

    fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun box(ctx: Context, fill: Int, stroke: Int = 0, radius: Int = 6): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(ctx, radius).toFloat()
            if (stroke != 0) setStroke(dp(ctx, 1), stroke)
        }

    fun button(ctx: Context, label: String, filled: Boolean, onClick: () -> Unit) =
        TextView(ctx).apply {
            text = label
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(if (filled) INK else PAPER)
            background = if (filled) box(ctx, AMBER) else box(ctx, 0, LINE)
            setPadding(dp(ctx, 14), dp(ctx, 10), dp(ctx, 14), dp(ctx, 10))
            isClickable = true
            setOnClickListener { onClick() }
        }
}
