package id.alih

import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.TextView

object Ui {
    const val INK = 0xFF14161A.toInt()
    const val DEEP = 0xFF0B0D10.toInt()
    const val RAISED = 0xFF1D2026.toInt()
    const val LINE = 0xFF2C3037.toInt()
    const val PAPER = 0xFFECE8DF.toInt()
    const val MUTED = 0xFF8D929B.toInt()
    const val AMBER = 0xFFF2B134.toInt()
    const val AMBER_DIM = 0xFFC99A3A.toInt()
    const val RED = 0xFFE0766B.toInt()
    const val GREEN = 0xFF8DBE8A.toInt()

    fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun box(ctx: Context, fill: Int, stroke: Int = 0, radius: Int = 3): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(ctx, radius).toFloat()
            if (stroke != 0) setStroke(dp(ctx, 1), stroke)
        }

    fun button(ctx: Context, label: String, filled: Boolean, onClick: () -> Unit) =
        TextView(ctx).apply {
            text = label
            textSize = 13.5f
            gravity = Gravity.CENTER
            letterSpacing = 0.03f
            typeface = if (filled) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            setTextColor(if (filled) INK else PAPER)
            background = if (filled) box(ctx, AMBER) else box(ctx, 0, LINE)
            setPadding(dp(ctx, 14), dp(ctx, 11), dp(ctx, 14), dp(ctx, 11))
            isClickable = true
            setOnClickListener { onClick() }
        }

    fun label(ctx: Context, text: String) = TextView(ctx).apply {
        this.text = text.uppercase()
        typeface = Typeface.MONOSPACE
        textSize = 11f
        letterSpacing = 0.12f
        setTextColor(MUTED)
    }

    fun clip(ctx: Context): String? {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)
        return t?.toString()?.trim()?.takeIf { it.isNotEmpty() }
    }
}
