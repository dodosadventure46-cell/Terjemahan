package id.alih

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View
import kotlin.math.max
import kotlin.math.min

class BoxesView(ctx: Context) : View(ctx) {
    class Box(val r: Rect, val text: String, val bg: Int)

    private var list: List<Box> = emptyList()
    private val d = ctx.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }

    fun set(l: List<Box>) {
        list = l
        invalidate()
    }

    private fun layoutFor(t: String, w: Int, size: Float): StaticLayout {
        tp.textSize = size
        return StaticLayout.Builder.obtain(t, 0, t.length, tp, w)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .build()
    }

    override fun onDraw(c: Canvas) {
        if (list.isEmpty()) return
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())
        val pad = 3 * d
        for (b in list) {
            val r = RectF(b.r)
            r.inset(-pad, -pad)
            fill.color = b.bg
            c.drawRoundRect(r, 4 * d, 4 * d, fill)
            val lum = (Color.red(b.bg) * 299 + Color.green(b.bg) * 587 + Color.blue(b.bg) * 114) / 1000
            tp.color = if (lum > 140) 0xFF111111.toInt() else 0xFFF5F5F5.toInt()
            val w = max(r.width() - 2 * pad, 10f).toInt()
            val hMax = r.height() - 2 * pad
            var size = min(hMax, 36 * d)
            var lay = layoutFor(b.text, w, size)
            while (lay.height > hMax && size > 9 * d) {
                size -= d
                lay = layoutFor(b.text, w, size)
            }
            c.save()
            c.translate(r.left + pad, r.top + max(0f, (r.height() - lay.height) / 2f))
            lay.draw(c)
            c.restore()
        }
    }
}
