package id.alih

import android.app.Activity
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.concurrent.CopyOnWriteArrayList

class Terminal(private val act: Activity) : LinearLayout(act) {
    companion object {
        private val lines = ArrayList<String>()
        private val main = Handler(Looper.getMainLooper())
        private val listeners = CopyOnWriteArrayList<Sink>()
        @Volatile private var current: Terminal? = null

        val sink: Sink = { line, replace -> print(line, replace) }

        fun listen(s: Sink) { listeners.addIfAbsent(s) }
        fun unlisten(s: Sink) { listeners.remove(s) }

        fun print(line: String, replace: Boolean = false) {
            main.post {
                if (replace && lines.isNotEmpty()) lines[lines.size - 1] = line else lines.add(line)
                while (lines.size > 600) lines.removeAt(0)
                current?.render()
                listeners.forEach { it(line, replace) }
            }
        }
    }

    private val log = TextView(act)
    private val scroll = ScrollView(act)
    private val input = EditText(act)

    init {
        orientation = VERTICAL
        background = Ui.box(act, Ui.DEEP, Ui.LINE, 3)
        val pad = Ui.dp(act, 12)

        log.apply {
            typeface = Typeface.MONOSPACE
            textSize = 12.5f
            setTextColor(Ui.PAPER)
            setTextIsSelectable(true)
            setPadding(pad, pad, pad, pad)
        }
        scroll.addView(log)
        addView(scroll, LayoutParams(-1, 0, 1f))

        addView(rule())

        val chips = LinearLayout(act).apply {
            orientation = HORIZONTAL
            setPadding(pad, Ui.dp(act, 8), pad, Ui.dp(act, 8))
        }
        listOf("help", "update", "update nightly", "stop", "clear").forEach { c ->
            chips.addView(TextView(act).apply {
                text = c
                typeface = Typeface.MONOSPACE
                textSize = 12f
                setTextColor(Ui.MUTED)
                background = Ui.box(act, 0, Ui.LINE, 3)
                setPadding(Ui.dp(act, 10), Ui.dp(act, 6), Ui.dp(act, 10), Ui.dp(act, 6))
                setOnClickListener { exec(c) }
            }, LayoutParams(-2, -2).apply { marginEnd = Ui.dp(act, 6) })
        }
        addView(HorizontalScrollView(act).apply {
            isHorizontalScrollBarEnabled = false
            addView(chips)
        })

        addView(rule())

        val row = LinearLayout(act).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, 0, Ui.dp(act, 8), 0)
        }
        row.addView(TextView(act).apply {
            text = "vardex ›"
            typeface = Typeface.MONOSPACE
            textSize = 13f
            setTextColor(Ui.AMBER)
        })
        input.apply {
            typeface = Typeface.MONOSPACE
            textSize = 14f
            setTextColor(Ui.PAPER)
            setHintTextColor(Ui.MUTED)
            hint = " tempel link atau ketik perintah"
            background = null
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(Ui.dp(act, 8), Ui.dp(act, 13), Ui.dp(act, 6), Ui.dp(act, 13))
            setOnEditorActionListener { _, _, _ -> submit(); true }
        }
        row.addView(input, LayoutParams(0, -2, 1f))
        row.addView(TextView(act).apply {
            text = "tempel"
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextColor(Ui.AMBER)
            setPadding(Ui.dp(act, 10), Ui.dp(act, 10), Ui.dp(act, 6), Ui.dp(act, 10))
            setOnClickListener {
                Ui.clip(act)?.let { input.setText(it); input.setSelection(input.text.length) }
            }
        })
        addView(row, LayoutParams(-1, -2))

        if (lines.isEmpty()) {
            lines.add("VarDeX terminal")
            lines.add("Tempel link lalu Enter. Ketik help untuk daftar perintah.")
        }
        current = this
        render()
    }

    private fun rule() = View(act).apply {
        setBackgroundColor(Ui.LINE)
    }.also { it.layoutParams = LayoutParams(-1, Ui.dp(act, 1)) }

    override fun onDetachedFromWindow() {
        if (current === this) current = null
        super.onDetachedFromWindow()
    }

    private fun colorFor(l: String): Int = when {
        l.startsWith("$ ") -> Ui.AMBER
        l.contains("ERROR") || l.startsWith("Gagal") || l.startsWith("YouTube menolak") -> Ui.RED
        l.startsWith("WARNING") -> Ui.AMBER_DIM
        l.startsWith("Selesai") || l.startsWith("Tersimpan") -> Ui.GREEN
        l.startsWith("[") -> Ui.MUTED
        else -> 0
    }

    private fun render() {
        val sb = SpannableStringBuilder()
        lines.forEachIndexed { i, l ->
            val start = sb.length
            sb.append(l)
            val c = colorFor(l)
            if (c != 0) sb.setSpan(ForegroundColorSpan(c), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (i < lines.size - 1) sb.append('\n')
        }
        log.text = sb
        scroll.post { scroll.fullScroll(FOCUS_DOWN) }
    }

    private fun tokenize(s: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var q = false
        for (c in s) {
            when {
                c == '"' -> q = !q
                c.isWhitespace() && !q -> if (sb.isNotEmpty()) { out.add(sb.toString()); sb.clear() }
                else -> sb.append(c)
            }
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    private fun submit() {
        val s = input.text.toString().trim()
        input.setText("")
        if (s.isNotEmpty()) exec(s)
    }

    private fun exec(s: String) {
        print("$ $s")
        val t = tokenize(s)
        if (t.isEmpty()) return
        val cmd = t[0].lowercase()
        val arg = t.getOrNull(1)
        when {
            cmd == "help" -> help()
            cmd == "clear" -> { lines.clear(); render() }
            cmd == "update" -> Downloader.update(act, arg?.lowercase() == "nightly", sink)
            cmd == "stop" -> Downloader.stop(sink)
            cmd == "mp3" && arg != null -> Downloader.start(act, Downloader.audioArgs(arg), sink)
            cmd == "dl" && arg != null -> Downloader.start(act, Downloader.videoArgs(arg), sink)
            (cmd == "yt-dlp" || cmd == "ytdlp") && arg != null ->
                Downloader.start(act, t.drop(1), sink)
            cmd.startsWith("http") -> Downloader.start(act, Downloader.videoArgs(t[0]), sink)
            else -> print("Perintah tidak dikenal: $cmd. Ketik help.")
        }
    }

    private fun help() {
        print("<link>            unduh video (maks 1080p, mp4)")
        print("mp3 <link>        unduh audio saja, mp3")
        print("yt-dlp <opsi>     perintah yt-dlp mentah, contoh:")
        print("                  yt-dlp -F <link>   (daftar format)")
        print("update            perbarui yt-dlp (stable)")
        print("update nightly    perbarui ke nightly (perbaikan YouTube tercepat)")
        print("stop              batalkan unduhan")
        print("clear             bersihkan layar")
        print("Hasil disimpan di Download/VarDeX.")
    }
}
