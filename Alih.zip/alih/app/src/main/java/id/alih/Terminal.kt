package id.alih

import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class Terminal(private val act: Activity) : LinearLayout(act) {
    companion object {
        private val lines = ArrayList<String>()
        private val main = Handler(Looper.getMainLooper())
        @Volatile private var current: Terminal? = null

        val sink: Sink = { line, replace -> print(line, replace) }

        fun print(line: String, replace: Boolean = false) {
            main.post {
                if (replace && lines.isNotEmpty()) lines[lines.size - 1] = line else lines.add(line)
                while (lines.size > 600) lines.removeAt(0)
                current?.render()
            }
        }
    }

    private val log = TextView(act)
    private val scroll = ScrollView(act)
    private val input = EditText(act)

    init {
        orientation = VERTICAL
        background = Ui.box(act, 0xFF0E1013.toInt(), Ui.LINE, 6)
        val pad = Ui.dp(act, 12)

        log.apply {
            typeface = Typeface.MONOSPACE
            textSize = 12.5f
            setTextColor(Ui.PAPER)
            setTextIsSelectable(true)
            setPadding(pad, pad, pad, pad)
        }
        scroll.addView(log)
        addView(scroll, LayoutParams(-1, 0, 1f))

        val row = LinearLayout(act).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, 0, Ui.dp(act, 6), 0)
            background = Ui.box(act, Ui.RAISED, Ui.LINE, 6)
        }
        row.addView(TextView(act).apply {
            text = "$"
            typeface = Typeface.MONOSPACE
            textSize = 15f
            setTextColor(Ui.AMBER)
        })
        input.apply {
            typeface = Typeface.MONOSPACE
            textSize = 14f
            setTextColor(Ui.PAPER)
            setHintTextColor(Ui.MUTED)
            hint = " tempel link atau ketik help"
            background = null
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(Ui.dp(act, 6), Ui.dp(act, 12), Ui.dp(act, 6), Ui.dp(act, 12))
            setOnEditorActionListener { _, _, _ -> submit(); true }
        }
        row.addView(input, LayoutParams(0, -2, 1f))
        row.addView(Ui.button(act, "Tempel", false) { paste() })
        addView(row, LayoutParams(-1, -2))

        if (lines.isEmpty()) {
            lines.add("VarDeX terminal")
            lines.add("Tempel link video lalu Enter. Ketik help untuk daftar perintah.")
        }
        current = this
        render()
    }

    override fun onDetachedFromWindow() {
        if (current === this) current = null
        super.onDetachedFromWindow()
    }

    private fun render() {
        log.text = lines.joinToString("\n")
        scroll.post { scroll.fullScroll(FOCUS_DOWN) }
    }

    private fun paste() {
        val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(act)
        if (!t.isNullOrBlank()) {
            input.setText(t.toString().trim())
            input.setSelection(input.text.length)
        }
    }

    private fun tokenize(s: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var q = false
        for (c in s) {
            when {
                c == '"' -> q = !q
                c.isWhitespace() && !q -> if (sb.isNotEmpty()) { out.add(sb.toString()); sb.clear() }
                else -> sb.append(c)
            }
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    private fun submit() {
        val s = input.text.toString().trim()
        input.setText("")
        if (s.isEmpty()) return
        print("$ $s")
        val t = tokenize(s)
        val cmd = t[0].lowercase()
        val arg = t.getOrNull(1)
        when {
            cmd == "help" -> help()
            cmd == "clear" -> { lines.clear(); render() }
            cmd == "update" -> Downloader.update(act, sink)
            cmd == "stop" -> Downloader.stop(sink)
            cmd == "mp3" && arg != null -> Downloader.start(act, Downloader.audioArgs(arg), sink)
            cmd == "dl" && arg != null -> Downloader.start(act, Downloader.videoArgs(arg), sink)
            (cmd == "yt-dlp" || cmd == "ytdlp") && arg != null ->
                Downloader.start(act, t.drop(1), sink)
            cmd.startsWith("http") -> Downloader.start(act, Downloader.videoArgs(t[0]), sink)
            else -> print("Perintah tidak dikenal: $cmd. Ketik help.")
        }
    }

    private fun help() {
        print("<link>            unduh video (maks 1080p, mp4)")
        print("mp3 <link>        unduh audio saja, mp3")
        print("yt-dlp <opsi>     perintah yt-dlp mentah, contoh:")
        print("                  yt-dlp -F <link>   (daftar format)")
        print("update            perbarui yt-dlp")
        print("stop              batalkan unduhan")
        print("clear             bersihkan layar")
        print("Hasil disimpan di Download/VarDeX.")
    }
}
