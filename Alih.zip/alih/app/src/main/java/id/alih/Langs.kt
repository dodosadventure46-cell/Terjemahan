package id.alih

import com.google.mlkit.nl.translate.TranslateLanguage
import java.util.Locale

object Langs {
    const val DEFAULT = "en"
    private val top = listOf("en", "ja", "ko", "zh")

    fun name(tag: String): String =
        Locale.forLanguageTag(tag).getDisplayLanguage(Locale("id"))
            .replaceFirstChar { it.uppercase() }

    fun all(): List<String> {
        val rest = TranslateLanguage.getAllLanguages()
            .filter { it != TranslateLanguage.INDONESIAN && it !in top }
            .sortedBy { name(it) }
        return top + rest
    }
}
