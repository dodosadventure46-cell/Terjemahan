package id.alih

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.os.SystemClock
import android.text.InputType
import android.text.TextUtils
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

class PasteView(private val act: Activity) : ScrollView(act) {
    private class Bar(ctx: Context) : View(ctx) {
        var ratio = 0f
            set(v) { field = v; invalidate() }
        var indeterminate = false
            set(v) { field = v; invalidate() }
        private val track = Paint().apply { color = Ui.LINE }
        private val fill = Paint().apply { color = Ui.AMBER }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            c.drawRect(0f, 0f, w, h, track)
            if (indeterminate) {
                val t = (SystemClock.uptimeMillis() % 1200) / 1200f
                val seg = w * 0.25f
                val x = -seg + t * (w + seg)
                c.drawRect(max(x, 0f), 0f, min(x + seg, w), h, fill)
                postInvalidateOnAnimation()
            } else {
                c.drawRect(0f, 0f, w * ratio.coerceIn(0f, 1f), h, fill)
            }
        }
    }

    private fun d(v: Int) = Ui.dp(act, v)
    private fun prefs() = act.getSharedPreferences("alih", Context.MODE_PRIVATE)

    private val input = EditText(act)
    private val stateTv = TextView(act)
    private val titleTv = TextView(act)
    private val detailTv = TextView(act)
    private val bar = Bar(act)
    private val history = LinearLayout(act)
    private val histLabel = Ui.label(act, "Tersimpan di Download/VarDeX")
    private val fmtViews = ArrayList<TextView>()
    private lateinit var action: TextView
    private var running = false
    private var fmt = prefs().getInt("fmt", 0)
    private val names = listOf("Video 1080p", "Video 720p", "MP3")
    private val listener: Sink = { line, _ -> onLine(line.trim()) }

    private val pctRe = Regex("""(\d+(?:\.\d+)?)%""")
    private val speedRe = Regex("""at\s+(\S+/s)""")
    private val etaRe = Regex("""ETA\s+(\S+)""")
    private val nameRe = Regex("""\s*\[[^\]]+\](\.f\d+)?\.\w+$""")

    init {
        isFillViewport = true
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, d(18), 0, d(24))
        }
        addView(col)

        col.addView(Ui.label(act, "Link video"))
        input.apply {
            hint = "https://"
            textSize = 14f
            setTextColor(Ui.PAPER)
            setHintTextColor(Ui.MUTED)
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            background = Ui.box(act, Ui.RAISED, Ui.LINE, 3)
            setPadding(d(12), d(13), d(12), d(13))
        }
        col.addView(input, lp(top = 6))

        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Ui.button(act, "Tempel dari clipboard", false) { paste() },
            LinearLayout.LayoutParams(0, -2, 2f).apply { marginEnd = d(8) })
        row.addView(Ui.button(act, "Hapus", false) { input.setText("") },
            LinearLayout.LayoutParams(0, -2, 1f))
        col.addView(row, lp(top = 8))

        col.addView(Ui.label(act, "Format"), lp(top = 22))
        val seg = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        names.forEachIndexed { i, n ->
            val tv = TextView(act).apply {
                text = n
                textSize = 13f
                gravity = android.view.Gravity.CENTER
                setPadding(d(6), d(11), d(6), d(11))
                setOnClickListener { setFmt(i) }
            }
            fmtViews.add(tv)
            seg.addView(tv, LinearLayout.LayoutParams(0, -2, 1f).apply {
                if (i < names.size - 1) marginEnd = d(6)
            })
        }
        col.addView(seg, lp(top = 6))
        setFmt(fmt)

        action = Ui.button(act, "Unduh", true) { onAction() }
        col.addView(action, lp(top = 20))

        col.addView(View(act).apply { setBackgroundColor(Ui.LINE) },
            LinearLayout.LayoutParams(-1, d(1)).apply { topMargin = d(28); bottomMargin = d(16) })

        stateTv.apply {
            typeface = Typeface.MONOSPACE
            textSize = 11f
            letterSpacing = 0.12f
        }
        col.addView(stateTv)
        titleTv.apply {
            textSize = 15f
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, d(6), 0, d(10))
        }
        col.addView(titleTv)
        col.addView(bar, LinearLayout.LayoutParams(-1, d(3)))
        detailTv.apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextColor(Ui.MUTED)
            setPadding(0, d(8), 0, 0)
        }
        col.addView(detailTv)

        histLabel.visibility = View.GONE
        col.addView(histLabel, lp(top = 28))
        history.orientation = LinearLayout.VERTICAL
        col.addView(history, lp(top = 4))

        idle()
    }

    private fun lp(top: Int) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(top) }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        Terminal.listen(listener)
    }

    override fun onDetachedFromWindow() {
        Terminal.unlisten(listener)
        super.onDetachedFromWindow()
    }

    private fun setFmt(i: Int) {
        fmt = i
        prefs().edit().putInt("fmt", i).apply()
        fmtViews.forEachIndexed { k, tv ->
            val sel = k == i
            tv.setTextColor(if (sel) Ui.INK else Ui.PAPER)
            tv.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            tv.background = if (sel) Ui.box(act, Ui.AMBER) else Ui.box(act, 0, Ui.LINE)
        }
    }

    private fun paste() {
        val t = Ui.clip(act)
        if (t == null) {
            show("Clipboard kosong", Ui.RED, null, false)
        } else {
            input.setText(t)
            input.setSelection(input.text.length)
        }
    }

    private fun idle() {
        stateTv.text = "SIAP"
        stateTv.setTextColor(Ui.MUTED)
        titleTv.text = "Tempel link, pilih format, lalu Unduh."
        titleTv.setTextColor(Ui.MUTED)
        detailTv.text = ""
        bar.indeterminate = false
        bar.ratio = 0f
    }

    private fun show(state: String, color: Int, title: String?, indeterminate: Boolean) {
        stateTv.text = state.uppercase()
        stateTv.setTextColor(color)
        if (title != null) {
            titleTv.text = title
            titleTv.setTextColor(Ui.PAPER)
        }
        bar.indeterminate = indeterminate
    }

    private fun setRunning(v: Boolean) {
        running = v
        action.text = if (v) "Batalkan" else "Unduh"
        action.background = if (v) Ui.box(act, 0, Ui.AMBER) else Ui.box(act, Ui.AMBER)
        action.setTextColor(if (v) Ui.AMBER else Ui.INK)
    }

    private fun onAction() {
        if (running || Downloader.busy) {
            Downloader.stop(Terminal.sink)
            return
        }
        if (input.text.isNullOrBlank()) paste()
        val url = input.text.toString().trim()
        if (!url.startsWith("http", true)) {
            show("Link tidak valid", Ui.RED, "Tempel link yang diawali http.", false)
            return
        }
        val args = when (fmt) {
            0 -> Downloader.videoArgs(url, 1080)
            1 -> Downloader.videoArgs(url, 720)
            else -> Downloader.audioArgs(url)
        }
        setRunning(true)
        bar.ratio = 0f
        detailTv.text = ""
        show("Menyiapkan", Ui.AMBER, url, true)
        Terminal.print("$ " + (if (fmt == 2) "mp3 " else "dl ") + url)
        Downloader.start(act, args, Terminal.sink)
    }

    private fun addHistory(path: String) {
        histLabel.visibility = View.VISIBLE
        history.addView(TextView(act).apply {
            text = path
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextColor(Ui.PAPER)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.MIDDLE
            setPadding(0, d(8), 0, d(8))
        }, 0)
        while (history.childCount > 6) history.removeViewAt(history.childCount - 1)
    }

    private fun onLine(l: String) {
        when {
            l.startsWith("Menyiapkan") || l.startsWith("Memperbarui") -> {
                setRunning(true)
                show("Menyiapkan", Ui.AMBER, null, true)
            }
            l.startsWith("[youtube]") || l.startsWith("[info]") || l.startsWith("[generic]") ||
                l.startsWith("[tiktok]") || l.startsWith("[Instagram]") -> {
                if (running) show("Membaca link", Ui.AMBER, null, true)
            }
            l.startsWith("[download] Destination:") -> {
                val n = l.substringAfter("Destination:").trim().substringAfterLast('/')
                setRunning(true)
                show("Mengunduh", Ui.AMBER, n.replace(nameRe, ""), false)
            }
            l.startsWith("[download]") && l.contains("%") -> {
                val p = pctRe.find(l)?.groupValues?.get(1)?.toFloatOrNull()
                if (p != null) {
                    setRunning(true)
                    bar.indeterminate = false
                    bar.ratio = p / 100f
                    stateTv.text = "MENGUNDUH"
                    stateTv.setTextColor(Ui.AMBER)
                    val sp = speedRe.find(l)?.groupValues?.get(1)
                    val eta = etaRe.find(l)?.groupValues?.get(1)
                    detailTv.text = listOfNotNull(
                        "%.0f%%".format(p), sp, eta?.let { "sisa $it" }
                    ).joinToString("  ·  ")
                }
            }
            l.startsWith("[Merger]") || l.startsWith("[ExtractAudio]") ||
                l.startsWith("[VideoConvertor]") || l.startsWith("[Fixup") -> {
                show("Memproses", Ui.AMBER, null, true)
                detailTv.text = ""
            }
            l.startsWith("Tersimpan:") -> addHistory(l.substringAfter("Tersimpan:").trim())
            l.startsWith("Selesai") -> {
                setRunning(false)
                show("Selesai", Ui.GREEN, null, false)
                bar.ratio = 1f
                detailTv.text = l
            }
            l.startsWith("Gagal") -> {
                setRunning(false)
                show("Gagal", Ui.RED, null, false)
                detailTv.text = "Lihat detail di mode Terminal."
            }
            l.startsWith("Dibatalkan") -> {
                setRunning(false)
                show("Dibatalkan", Ui.MUTED, null, false)
                detailTv.text = ""
            }
        }
    }
}
