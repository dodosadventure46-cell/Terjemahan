package id.alih

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min

class FloatService : Service() {
    companion object {
        @Volatile var running = false
        const val STOP = "id.alih.STOP"
        private const val CHANNEL = "alih"
    }

    private lateinit var wm: WindowManager
    private lateinit var bubble: BubbleView
    private lateinit var panel: LinearLayout
    private lateinit var bubbleLp: LP
    private lateinit var panelLp: LP
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var status: TextView
    private lateinit var srcBtn: TextView
    private lateinit var langList: ScrollView

    private val handler = Handler(Looper.getMainLooper())
    private val langId = LanguageIdentification.getClient()
    private val translators = HashMap<String, Translator>()
    private var source: String? = null
    private var seq = 0
    private var pending: Runnable? = null
    private var panelShown = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        buildBubble()
        buildPanel()
        wm.addView(bubble, bubbleLp)
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        runCatching { wm.removeView(if (panelShown) panel else bubble) }
        translators.values.forEach { it.close() }
        langId.close()
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Alih", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0, Intent(this, FloatService::class.java).setAction(STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Alih aktif")
            .setContentText("Ketuk Hentikan untuk menutup bulatan.")
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_stat), "Hentikan", stop
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun buildBubble() {
        bubble = BubbleView(this)
        bubbleLp = LP(
            dp(56), dp(56), LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(220)
        }
        drag(bubble, bubble, bubbleLp) { showPanel() }
    }

    private fun buildPanel() {
        val width = min(resources.displayMetrics.widthPixels - dp(24), dp(360))
        panelLp = LP(
            width, LP.WRAP_CONTENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            softInputMode = LP.SOFT_INPUT_ADJUST_RESIZE
        }

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.box(this@FloatService, Ui.INK, Ui.LINE, 10)
            setPadding(dp(12), dp(8), dp(12), dp(12))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "Alih"
            textSize = 18f
            setTextColor(Ui.PAPER)
            typeface = android.graphics.Typeface.SERIF
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(iconText("—") { hidePanel() })
        header.addView(iconText("✕") { stopSelf() })
        panel.addView(header)
        drag(header, panel, panelLp, null)

        srcBtn = TextView(this).apply {
            textSize = 13f
            setTextColor(Ui.AMBER)
            setPadding(0, dp(6), 0, dp(6))
            setOnClickListener {
                langList.visibility =
                    if (langList.visibility == View.GONE) View.VISIBLE else View.GONE
            }
        }
        panel.addView(srcBtn)
        setSource(null)

        langList = ScrollView(this).apply {
            visibility = View.GONE
            background = Ui.box(this@FloatService, Ui.RAISED, Ui.LINE, 6)
        }
        val items = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        items.addView(langItem("Otomatis (deteksi)", null))
        TranslateLanguage.getAllLanguages()
            .filter { it != TranslateLanguage.INDONESIAN }
            .map { it to Locale.forLanguageTag(it).getDisplayLanguage(Locale("id")) }
            .sortedBy { it.second }
            .forEach { items.addView(langItem(it.second.replaceFirstChar { c -> c.uppercase() }, it.first)) }
        langList.addView(items)
        panel.addView(langList, LinearLayout.LayoutParams(-1, dp(180)))

        input = EditText(this).apply {
            hint = "Ketik atau tempel teks"
            textSize = 15f
            setTextColor(Ui.PAPER)
            setHintTextColor(Ui.MUTED)
            background = Ui.box(this@FloatService, Ui.RAISED, Ui.LINE, 6)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            minLines = 2
            maxLines = 4
            gravity = Gravity.TOP
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) = schedule()
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        panel.addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun add(b: TextView) = row.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply {
            marginEnd = dp(6)
        })
        add(Ui.button(this, "Tempel", false) { paste() })
        add(Ui.button(this, "Salin", false) { copy() })
        add(Ui.button(this, "Hapus", false) { input.setText("") })
        panel.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(8)
            bottomMargin = dp(8)
        })

        output = TextView(this).apply {
            textSize = 16f
            setTextColor(Ui.PAPER)
            setTextIsSelectable(true)
            maxLines = 8
            movementMethod = ScrollingMovementMethod()
        }
        panel.addView(output)

        status = TextView(this).apply {
            textSize = 12f
            setTextColor(Ui.MUTED)
            setPadding(0, dp(6), 0, 0)
        }
        panel.addView(status)
    }

    private fun iconText(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 16f
        setTextColor(Ui.MUTED)
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(8), dp(14), dp(8))
        setOnClickListener { onClick() }
    }

    private fun langItem(label: String, tag: String?) = TextView(this).apply {
        text = label
        textSize = 14f
        setTextColor(Ui.PAPER)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setOnClickListener {
            setSource(tag)
            langList.visibility = View.GONE
            schedule(0)
        }
    }

    private fun setSource(tag: String?) {
        source = tag
        val name = if (tag == null) "Otomatis"
        else Locale.forLanguageTag(tag).getDisplayLanguage(Locale("id"))
            .replaceFirstChar { it.uppercase() }
        srcBtn.text = "Dari: $name  →  Indonesia"
    }

    private fun drag(
        handle: View, target: View, lp: LP, onTap: (() -> Unit)?
    ) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt()
                    val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = ox + dx
                        lp.y = oy + dy
                        wm.updateViewLayout(target, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap?.invoke()
            }
            true
        }
    }

    private fun showPanel() {
        if (panelShown) return
        val dm = resources.displayMetrics
        panelLp.x = bubbleLp.x.coerceIn(0, (dm.widthPixels - panelLp.width).coerceAtLeast(0))
        panelLp.y = bubbleLp.y.coerceIn(0, dm.heightPixels / 2)
        wm.removeView(bubble)
        wm.addView(panel, panelLp)
        panelShown = true
    }

    private fun hidePanel() {
        if (!panelShown) return
        bubbleLp.x = panelLp.x
        bubbleLp.y = panelLp.y
        wm.removeView(panel)
        wm.addView(bubble, bubbleLp)
        panelShown = false
    }

    private fun paste() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)
        if (t.isNullOrBlank()) status.text = "Clipboard kosong"
        else input.setText(t)
    }

    private fun copy() {
        val t = output.text.toString()
        if (t.isBlank()) return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Alih", t))
        status.text = "Tersalin"
    }

    private fun schedule(delay: Long = 600) {
        pending?.let { handler.removeCallbacks(it) }
        val r = Runnable { run(input.text.toString().trim()) }
        pending = r
        handler.postDelayed(r, delay)
    }

    private fun run(text: String) {
        val id = ++seq
        if (text.isEmpty()) {
            output.text = ""
            status.text = ""
            return
        }
        status.text = "Memproses..."
        val manual = source
        if (manual != null) {
            translate(text, manual, id)
            return
        }
        langId.identifyLanguage(text)
            .addOnSuccessListener { tag ->
                if (id != seq) return@addOnSuccessListener
                val code = if (tag == "und") null else TranslateLanguage.fromLanguageTag(tag)
                if (code == null) {
                    output.text = ""
                    status.text = "Bahasa tidak terdeteksi. Pilih bahasa asal secara manual."
                } else {
                    translate(text, code, id)
                }
            }
            .addOnFailureListener {
                if (id == seq) status.text = "Deteksi bahasa gagal. Pilih manual."
            }
    }

    private fun translate(text: String, src: String, id: Int) {
        if (src == TranslateLanguage.INDONESIAN) {
            output.text = text
            status.text = "Sudah bahasa Indonesia"
            return
        }
        val tr = translators.getOrPut(src) {
            Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(src)
                    .setTargetLanguage(TranslateLanguage.INDONESIAN)
                    .build()
            )
        }
        val label = Locale.forLanguageTag(src).getDisplayLanguage(Locale("id"))
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                tr.translate(text)
                    .addOnSuccessListener { out ->
                        if (id != seq) return@addOnSuccessListener
                        output.text = out
                        status.text = "$label → Indonesia"
                    }
                    .addOnFailureListener {
                        if (id == seq) status.text = "Terjemahan gagal"
                    }
            }
            .addOnFailureListener {
                if (id == seq) status.text = "Model gagal diunduh. Cek internet."
            }
    }
}
