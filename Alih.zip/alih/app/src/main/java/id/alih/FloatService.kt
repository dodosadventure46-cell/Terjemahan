package id.alih

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.text.InputType
import android.widget.EditText
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.net.TrafficStats
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs
import kotlin.math.min

class FloatService : Service() {
    companion object {
        @Volatile var running = false
        const val STOP = "id.alih.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "alih"
        private const val TICK_MS = 300L
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var bubble: BubbleView
    private lateinit var panel: LinearLayout
    private lateinit var boxes: BoxesView
    private lateinit var bubbleLp: LP
    private lateinit var panelLp: LP
    private lateinit var boxesLp: LP
    private lateinit var status: TextView
    private lateinit var srcBtn: TextView
    private lateinit var toggleBtn: TextView
    private lateinit var langList: ScrollView
    private lateinit var dlInput: EditText
    private lateinit var dlStatus: TextView

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var thread: HandlerThread
    private lateinit var work: Handler

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var recognizer: TextRecognizer? = null
    private var translator: Translator? = null

    private var screenW = 0
    private var screenH = 0
    private var screenDpi = 0

    @Volatile private var modelReady = false
    @Volatile private var downloading = false
    @Volatile private var enabled = false
    @Volatile private var panelShown = false
    @Volatile private var boxesShown = false
    @Volatile private var busy = false
    @Volatile private var dirty = true
    @Volatile private var gen = 0
    @Volatile private var mask: BooleanArray? = null
    private var settle = 0
    private var lastSig: IntArray? = null
    private var lastBitmap: Bitmap? = null

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "src") prepare()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (projection == null && intent != null && intent.hasExtra(EXTRA_DATA)) startCapture(intent)
        return START_NOT_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("alih", MODE_PRIVATE)
        val dm = realMetrics()
        screenW = dm.widthPixels
        screenH = dm.heightPixels
        screenDpi = dm.densityDpi
        startAsForeground()
        thread = HandlerThread("alih-work").also { it.start() }
        work = Handler(thread.looper)
        buildBoxes()
        buildBubble()
        buildPanel()
        wm.addView(boxes, boxesLp)
        wm.addView(bubble, bubbleLp)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        prepare()
    }

    override fun onDestroy() {
        running = false
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        work.removeCallbacksAndMessages(null)
        ui.removeCallbacksAndMessages(null)
        runCatching { display?.release() }
        runCatching { reader?.close() }
        runCatching { projection?.stop() }
        runCatching { thread.quitSafely() }
        runCatching { wm.removeView(boxes) }
        runCatching { wm.removeView(if (panelShown) panel else bubble) }
        recognizer?.close()
        translator?.close()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun realMetrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        getSystemService(DisplayManager::class.java)
            .getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        return dm
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "VarDeX",NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0, Intent(this, FloatService::class.java).setAction(STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("VarDeX aktif")
            .setContentText("Ketuk Hentikan untuk menutup.")
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_stat), "Hentikan", stop
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- capture ----------

    @Suppress("DEPRECATION")
    private fun startCapture(intent: Intent) {
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data = intent.getParcelableExtra<Intent>(EXTRA_DATA) ?: return
        val mp = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                ui.post { stopSelf() }
            }
        }, ui)
        projection = mp
        val r = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        reader = r
        display = mp.createVirtualDisplay(
            "alih", screenW, screenH, screenDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, work
        )
        work.post(tick)
    }

    private val tick = object : Runnable {
        override fun run() {
            try {
                step()
            } catch (e: Exception) {
                setStatus("Error: ${e.message}")
            }
            work.postDelayed(this, TICK_MS)
        }
    }

    private fun step() {
        val img = reader?.acquireLatestImage()
        if (!enabled || panelShown) {
            img?.close()
            lastSig = null
            dirty = true
            settle = 0
            return
        }
        var changed = false
        if (img != null) {
            val bm = try { toBitmap(img) } finally { img.close() }
            val sig = signature(bm)
            val prev = lastSig
            val m = if (boxesShown) mask else null
            changed = prev == null || differs(prev, sig, m)
            if (changed) lastSig = sig
            if (!boxesShown) lastBitmap = bm
        }
        if (changed) {
            gen++
            dirty = true
            settle = 0
            if (boxesShown) {
                boxesShown = false
                ui.post { boxes.set(emptyList()) }
            }
            return
        }
        if (dirty) {
            settle++
            val bm = lastBitmap
            if (settle >= 2 && !busy && bm != null) {
                dirty = false
                busy = true
                val g = gen
                ui.post { process(bm, g) }
            }
        }
    }

    private fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        val rowPad = p.rowStride - p.pixelStride * img.width
        val full = Bitmap.createBitmap(
            img.width + rowPad / p.pixelStride, img.height, Bitmap.Config.ARGB_8888
        )
        full.copyPixelsFromBuffer(p.buffer)
        return if (rowPad == 0) full else Bitmap.createBitmap(full, 0, 0, img.width, img.height)
    }

    private fun signature(bm: Bitmap): IntArray {
        val s = Bitmap.createScaledBitmap(bm, 40, 80, false)
        val px = IntArray(40 * 80)
        s.getPixels(px, 0, 40, 0, 0, 40, 80)
        s.recycle()
        return IntArray(px.size) {
            (Color.red(px[it]) * 3 + Color.green(px[it]) * 6 + Color.blue(px[it])) / 10
        }
    }

    private fun differs(a: IntArray, b: IntArray, skip: BooleanArray?): Boolean {
        var n = 0
        for (i in a.indices) {
            if (skip != null && skip[i]) continue
            if (abs(a[i] - b[i]) > 30) n++
        }
        return n > 40
    }

    // ---------- OCR + translate ----------

    private fun makeRecognizer(src: String): TextRecognizer = when (src) {
        "ja" -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        "ko" -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        "zh" -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private fun prepare() {
        modelReady = false
        translator?.close()
        translator = null
        recognizer?.close()
        val src = prefs.getString("src", Langs.DEFAULT)!!
        recognizer = makeRecognizer(src)
        srcBtn.text = "Dari: ${Langs.name(src)}  →  Indonesia"
        val tr = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(src)
                .setTargetLanguage(TranslateLanguage.INDONESIAN)
                .build()
        )
        translator = tr
        downloading = true
        trackModel(Langs.name(src), tr)
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                if (translator === tr) {
                    downloading = false
                    modelReady = true
                    dirty = true
                    report("Model siap")
                }
            }
            .addOnFailureListener {
                if (translator === tr) {
                    downloading = false
                    report("Gagal unduh model: ${it.message}")
                }
            }
    }

    private fun report(text: String) {
        setStatus(text)
        val nm = getSystemService(NotificationManager::class.java)
        val stop = PendingIntent.getService(
            this, 0, Intent(this, FloatService::class.java).setAction(STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        nm.notify(
            1,
            Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("VarDeX aktif")
                .setContentText(text.replace('\n', ' '))
                .addAction(
                    Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_stat), "Hentikan", stop
                    ).build()
                )
                .build()
        )
    }

    private fun trackModel(name: String, tr: Translator) {
        val t0 = SystemClock.elapsedRealtime()
        val rx0 = TrafficStats.getTotalRxBytes()
        val r = object : Runnable {
            override fun run() {
                if (!downloading || translator !== tr) return
                val sec = (SystemClock.elapsedRealtime() - t0) / 1000
                val rx = TrafficStats.getTotalRxBytes()
                val text = if (rx0 == TrafficStats.UNSUPPORTED.toLong() || rx == TrafficStats.UNSUPPORTED.toLong()) {
                    "Mengunduh model $name... $sec dtk"
                } else {
                    val mb = (rx - rx0) / 1048576.0
                    val filled = (min(mb / 30.0, 0.95) * 10).toInt()
                    val bar = "█".repeat(filled) + "░".repeat(10 - filled)
                    "Mengunduh model $name\n$bar ≈%.1f MB (±30 MB) · %d dtk".format(mb, sec)
                }
                report(text)
                ui.postDelayed(this, 1000)
            }
        }
        ui.postDelayed(r, 400)
    }

    private fun bubbleRect(): Rect {
        val m = dp(6)
        return Rect(
            bubbleLp.x - m, bubbleLp.y - m,
            bubbleLp.x + bubbleLp.width + m, bubbleLp.y + bubbleLp.height + m
        )
    }

    private fun process(bm: Bitmap, g: Int) {
        val rec = recognizer
        val tr = translator
        if (rec == null || tr == null || !modelReady) {
            busy = false
            dirty = true
            return
        }
        setStatus("Membaca layar...")
        rec.process(InputImage.fromBitmap(bm, 0))
            .addOnSuccessListener { vt ->
                val src = prefs.getString("src", Langs.DEFAULT)!!
                val sep = if (src == "ja" || src == "zh") "" else " "
                val bub = bubbleRect()
                val items = vt.textBlocks.mapNotNull { b ->
                    val r = b.boundingBox ?: return@mapNotNull null
                    val t = b.lines.joinToString(sep) { it.text }.trim()
                    if (t.length < 2 || t.none { it.isLetter() } || Rect.intersects(r, bub)) null
                    else r to t
                }
                if (items.isEmpty()) {
                    busy = false
                    setStatus("Tidak ada teks terbaca")
                    return@addOnSuccessListener
                }
                val out = arrayOfNulls<BoxesView.Box>(items.size)
                var left = items.size
                items.forEachIndexed { i, (r, t) ->
                    tr.translate(t).addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            out[i] = BoxesView.Box(Rect(r), task.result, sample(bm, r))
                        }
                        left--
                        if (left == 0) finish(out.filterNotNull(), g)
                    }
                }
            }
            .addOnFailureListener {
                busy = false
                setStatus("OCR gagal: ${it.message}")
            }
    }

    private fun sample(bm: Bitmap, r: Rect): Int {
        val m = dp(3)
        val xs = intArrayOf(r.left - m, (r.left + r.right) / 2, r.right + m)
        val ys = intArrayOf(r.top - m, (r.top + r.bottom) / 2, r.bottom + m)
        var sr = 0; var sg = 0; var sb = 0; var n = 0
        for (xi in 0..2) for (yi in 0..2) {
            if (xi == 1 && yi == 1) continue
            val px = bm.getPixel(
                xs[xi].coerceIn(0, bm.width - 1), ys[yi].coerceIn(0, bm.height - 1)
            )
            sr += Color.red(px); sg += Color.green(px); sb += Color.blue(px); n++
        }
        return Color.rgb(sr / n, sg / n, sb / n)
    }

    private fun finish(list: List<BoxesView.Box>, g: Int) {
        busy = false
        if (g != gen) return
        if (list.isEmpty()) {
            setStatus("Terjemahan gagal")
            return
        }
        val m = BooleanArray(40 * 80)
        val pad = dp(8)
        for (b in list) {
            val x0 = ((b.r.left - pad).coerceAtLeast(0) * 40 / screenW).coerceIn(0, 39)
            val x1 = ((b.r.right + pad).coerceAtLeast(0) * 40 / screenW).coerceIn(0, 39)
            val y0 = ((b.r.top - pad).coerceAtLeast(0) * 80 / screenH).coerceIn(0, 79)
            val y1 = ((b.r.bottom + pad).coerceAtLeast(0) * 80 / screenH).coerceIn(0, 79)
            for (y in y0..y1) for (x in x0..x1) m[y * 40 + x] = true
        }
        mask = m
        boxesShown = true
        boxes.set(list)
        setStatus("${list.size} teks diterjemahkan")
    }

    private fun setStatus(s: String) {
        ui.post { if (::status.isInitialized) status.text = s }
    }

    // ---------- overlay UI ----------

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun buildBoxes() {
        boxes = BoxesView(this)
        boxesLp = LP(
            screenW, screenH, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCHABLE or
                LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = LP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
    }

    private fun buildBubble() {
        bubble = BubbleView(this)
        bubbleLp = LP(
            dp(56), dp(56), LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(220)
        }
        drag(bubble, bubble, bubbleLp) { showPanel() }
    }

    private fun buildPanel() {
        val width = min(screenW - dp(24), dp(340))
        panelLp = LP(
            width, LP.WRAP_CONTENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            softInputMode = LP.SOFT_INPUT_ADJUST_RESIZE
        }

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.box(this@FloatService, Ui.INK, Ui.LINE, 10)
            setPadding(dp(12), dp(8), dp(12), dp(12))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "VarDeX"
            textSize = 18f
            setTextColor(Ui.PAPER)
            typeface = android.graphics.Typeface.SERIF
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(iconText("—") { hidePanel() })
        header.addView(iconText("✕") { stopSelf() })
        panel.addView(header)
        drag(header, panel, panelLp, null)

        srcBtn = TextView(this).apply {
            textSize = 14f
            setTextColor(Ui.AMBER)
            setPadding(0, dp(8), 0, dp(8))
            setOnClickListener {
                langList.visibility =
                    if (langList.visibility == View.GONE) View.VISIBLE else View.GONE
            }
        }
        panel.addView(srcBtn)

        langList = ScrollView(this).apply {
            visibility = View.GONE
            background = Ui.box(this@FloatService, Ui.RAISED, Ui.LINE, 6)
        }
        val items = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        Langs.all().forEach { items.addView(langItem(it)) }
        langList.addView(items)
        panel.addView(langList, LinearLayout.LayoutParams(-1, dp(200)))

        toggleBtn = Ui.button(this, "", true) { toggle() }
        setToggleLabel()
        panel.addView(toggleBtn, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(8)
        })

        panel.addView(TextView(this).apply {
            text = "Unduh video"
            textSize = 13f
            setTextColor(Ui.MUTED)
            setPadding(0, dp(14), 0, dp(4))
        })
        dlInput = EditText(this).apply {
            hint = "Tempel link video"
            textSize = 14f
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setTextColor(Ui.PAPER)
            setHintTextColor(Ui.MUTED)
            background = Ui.box(this@FloatService, Ui.RAISED, Ui.LINE, 6)
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        panel.addView(dlInput)
        val dlRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun cell(b: TextView) = dlRow.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply {
            marginEnd = dp(6)
        })
        cell(Ui.button(this, "Tempel", false) { pasteLink() })
        cell(Ui.button(this, "Video", false) { download(false) })
        cell(Ui.button(this, "MP3", false) { download(true) })
        panel.addView(dlRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        dlStatus = TextView(this).apply {
            textSize = 12f
            setTextColor(Ui.MUTED)
            maxLines = 3
            setPadding(0, dp(6), 0, 0)
        }
        panel.addView(dlStatus)

        status = TextView(this).apply {
            textSize = 12f
            setTextColor(Ui.MUTED)
            setPadding(0, dp(8), 0, 0)
        }
        panel.addView(status)
    }

    private val dlSink: Sink = { line, _ -> ui.post { dlStatus.text = line.take(160) } }

    private fun pasteLink() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)
        if (t.isNullOrBlank()) dlStatus.text = "Clipboard kosong"
        else dlInput.setText(t.toString().trim())
    }

    private fun download(audio: Boolean) {
        val url = dlInput.text.toString().trim()
        if (!url.startsWith("http", true)) {
            dlStatus.text = "Link tidak valid"
            return
        }
        dlStatus.text = "Memulai..."
        Downloader.start(
            this,
            if (audio) Downloader.audioArgs(url) else Downloader.videoArgs(url),
            dlSink
        )
    }

    private fun iconText(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 16f
        setTextColor(Ui.MUTED)
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(8), dp(14), dp(8))
        setOnClickListener { onClick() }
    }

    private fun langItem(tag: String) = TextView(this).apply {
        text = Langs.name(tag)
        textSize = 14f
        setTextColor(Ui.PAPER)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setOnClickListener {
            langList.visibility = View.GONE
            prefs.edit().putString("src", tag).apply()
        }
    }

    private fun setToggleLabel() {
        toggleBtn.text = if (enabled) "Terjemah layar: HIDUP" else "Terjemah layar: MATI"
    }

    private fun toggle() {
        enabled = !enabled
        setToggleLabel()
        gen++
        if (!enabled) {
            boxesShown = false
            boxes.set(emptyList())
        } else {
            lastBitmap = null
            hidePanel()
        }
    }

    private fun drag(handle: View, target: View, lp: LP, onTap: (() -> Unit)?) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt()
                    val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = ox + dx
                        lp.y = oy + dy
                        wm.updateViewLayout(target, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap?.invoke()
            }
            true
        }
    }

    private fun showPanel() {
        if (panelShown) return
        panelShown = true
        boxesShown = false
        boxes.set(emptyList())
        panelLp.x = bubbleLp.x.coerceIn(0, (screenW - panelLp.width).coerceAtLeast(0))
        panelLp.y = bubbleLp.y.coerceIn(0, screenH / 2)
        wm.removeView(bubble)
        wm.addView(panel, panelLp)
    }

    private fun hidePanel() {
        if (!panelShown) return
        panelShown = false
        bubbleLp.x = panelLp.x
        bubbleLp.y = panelLp.y
        wm.removeView(panel)
        wm.addView(bubble, bubbleLp)
    }
}
