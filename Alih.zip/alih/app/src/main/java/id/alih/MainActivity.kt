package id.alih

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var grant: TextView
    private lateinit var toggle: TextView
    private lateinit var lang: TextView

    private fun prefs() = getSharedPreferences("alih", MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.INK
        window.navigationBarColor = Ui.INK

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.INK)
            val p = Ui.dp(this@MainActivity, 28)
            setPadding(p, Ui.dp(this@MainActivity, 72), p, p)
        }

        root.addView(TextView(this).apply {
            text = "Alih"
            textSize = 44f
            setTextColor(Ui.PAPER)
            typeface = android.graphics.Typeface.SERIF
        })
        root.addView(TextView(this).apply {
            text = "Terjemahkan teks di layar ke bahasa Indonesia."
            textSize = 15f
            setTextColor(Ui.MUTED)
            setPadding(0, Ui.dp(this@MainActivity, 6), 0, Ui.dp(this@MainActivity, 36))
        })

        info = TextView(this).apply {
            textSize = 14f
            setTextColor(Ui.PAPER)
            setPadding(0, 0, 0, Ui.dp(this@MainActivity, 16))
        }
        root.addView(info)

        val gap = Ui.dp(this, 10)

        lang = Ui.button(this, "", false) { pickLang() }
        root.addView(lang, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = gap })

        grant = Ui.button(this, "Beri izin layar mengambang", false) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        root.addView(grant, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = gap })

        toggle = Ui.button(this, "Mulai", true) { onToggle() }
        root.addView(toggle, LinearLayout.LayoutParams(-1, -2))

        root.addView(TextView(this).apply {
            text = "Setelah Mulai, ketuk bulatan A lalu nyalakan Terjemah layar. " +
                "Hasil muncul sekitar setengah detik setelah scroll berhenti. " +
                "Model bahasa diunduh sekali, setelah itu bisa offline."
            textSize = 12f
            setTextColor(Ui.MUTED)
            setPadding(0, Ui.dp(this@MainActivity, 24), 0, 0)
        })

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val ok = Settings.canDrawOverlays(this)
        grant.visibility = if (ok) View.GONE else View.VISIBLE
        toggle.visibility = if (ok) View.VISIBLE else View.GONE
        toggle.text = if (FloatService.running) "Hentikan" else "Mulai"
        lang.text = "Bahasa asal: " + Langs.name(prefs().getString("src", Langs.DEFAULT)!!)
        info.text = when {
            !ok -> "Izin tampil di atas aplikasi lain belum aktif."
            FloatService.running -> "Aktif. Cari bulatan A di layar."
            else -> "Siap dijalankan."
        }
    }

    private fun pickLang() {
        val tags = Langs.all()
        AlertDialog.Builder(this)
            .setTitle("Bahasa asal komik")
            .setItems(tags.map { Langs.name(it) }.toTypedArray()) { _, i ->
                prefs().edit().putString("src", tags[i]).apply()
                refresh()
            }
            .show()
    }

    private fun onToggle() {
        if (FloatService.running) {
            stopService(Intent(this, FloatService::class.java))
            FloatService.running = false
            refresh()
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, FloatService::class.java)
                    .putExtra(FloatService.EXTRA_CODE, resultCode)
                    .putExtra(FloatService.EXTRA_DATA, data)
            )
            FloatService.running = true
        }
        refresh()
    }
}
