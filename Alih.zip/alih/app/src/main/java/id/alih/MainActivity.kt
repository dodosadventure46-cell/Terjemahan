package id.alih

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var grant: TextView
    private lateinit var toggle: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.INK
        window.navigationBarColor = Ui.INK

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.INK)
            val p = Ui.dp(this@MainActivity, 28)
            setPadding(p, Ui.dp(this@MainActivity, 72), p, p)
        }

        root.addView(TextView(this).apply {
            text = "Alih"
            textSize = 44f
            setTextColor(Ui.PAPER)
            typeface = android.graphics.Typeface.SERIF
        })
        root.addView(TextView(this).apply {
            text = "Terjemahan mengambang ke bahasa Indonesia."
            textSize = 15f
            setTextColor(Ui.MUTED)
            setPadding(0, Ui.dp(this@MainActivity, 6), 0, Ui.dp(this@MainActivity, 40))
        })

        info = TextView(this).apply {
            textSize = 14f
            setTextColor(Ui.PAPER)
            setPadding(0, 0, 0, Ui.dp(this@MainActivity, 16))
        }
        root.addView(info)

        grant = Ui.button(this, "Beri izin layar mengambang", false) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        root.addView(grant, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = Ui.dp(this@MainActivity, 10)
        })

        toggle = Ui.button(this, "Mulai", true) { onToggle() }
        root.addView(toggle, LinearLayout.LayoutParams(-1, -2))

        root.addView(TextView(this).apply {
            text = "Model bahasa diunduh sekali (sekitar 30 MB per bahasa), setelah itu bisa offline."
            textSize = 12f
            setTextColor(Ui.MUTED)
            setPadding(0, Ui.dp(this@MainActivity, 24), 0, 0)
        })

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val ok = Settings.canDrawOverlays(this)
        grant.visibility = if (ok) View.GONE else View.VISIBLE
        toggle.visibility = if (ok) View.VISIBLE else View.GONE
        toggle.text = if (FloatService.running) "Hentikan" else "Mulai"
        info.text = when {
            !ok -> "Izin tampil di atas aplikasi lain belum aktif."
            FloatService.running -> "Aktif. Cari bulatan A di layar."
            else -> "Siap dijalankan."
        }
    }

    private fun onToggle() {
        val svc = Intent(this, FloatService::class.java)
        if (FloatService.running) {
            stopService(svc)
            FloatService.running = false
        } else {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            startForegroundService(svc)
            FloatService.running = true
        }
        refresh()
    }
}
