package id.alih

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var grant: TextView
    private lateinit var toggle: TextView
    private lateinit var lang: TextView

    private fun prefs() = getSharedPreferences("alih", MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.INK
        window.navigationBarColor = Ui.INK

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.INK)
            val p = Ui.dp(this@MainActivity, 18)
            setPadding(p, Ui.dp(this@MainActivity, 44), p, p)
        }

        root.addView(TextView(this).apply {
            text = "VarDeX"
            textSize = 32f
            setTextColor(Ui.PAPER)
            typeface = android.graphics.Typeface.SERIF
        })
        root.addView(TextView(this).apply {
            text = "Unduh video lewat terminal, terjemah layar lewat bulatan."
            textSize = 13f
            setTextColor(Ui.MUTED)
            setPadding(0, Ui.dp(this@MainActivity, 2), 0, Ui.dp(this@MainActivity, 14))
        })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val gap = Ui.dp(this, 8)

        lang = Ui.button(this, "", false) { pickLang() }
        row.addView(lang, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = gap })

        grant = Ui.button(this, "Izin layar mengambang", false) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        row.addView(grant, LinearLayout.LayoutParams(0, -2, 1f))

        toggle = Ui.button(this, "", true) { onToggle() }
        row.addView(toggle, LinearLayout.LayoutParams(0, -2, 1f))

        root.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = Ui.dp(this@MainActivity, 12)
        })

        root.addView(Terminal(this), LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val ok = Settings.canDrawOverlays(this)
        grant.visibility = if (ok) View.GONE else View.VISIBLE
        toggle.visibility = if (ok) View.VISIBLE else View.GONE
        toggle.text = if (FloatService.running) "Hentikan bulatan" else "Mulai bulatan"
        lang.text = "Dari: " + Langs.name(prefs().getString("src", Langs.DEFAULT)!!)
    }

    private fun pickLang() {
        val tags = Langs.all()
        AlertDialog.Builder(this)
            .setTitle("Bahasa asal komik")
            .setItems(tags.map { Langs.name(it) }.toTypedArray()) { _, i ->
                prefs().edit().putString("src", tags[i]).apply()
                refresh()
            }
            .show()
    }

    private fun onToggle() {
        if (FloatService.running) {
            stopService(Intent(this, FloatService::class.java))
            FloatService.running = false
            refresh()
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, FloatService::class.java)
                    .putExtra(FloatService.EXTRA_CODE, resultCode)
                    .putExtra(FloatService.EXTRA_DATA, data)
            )
            FloatService.running = true
        }
        refresh()
    }
}
