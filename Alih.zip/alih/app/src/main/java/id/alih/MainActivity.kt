package id.alih

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var grant: TextView
    private lateinit var toggle: TextView
    private lateinit var lang: TextView
    private lateinit var pages: List<View>
    private val tabText = ArrayList<TextView>()
    private val tabLine = ArrayList<View>()

    private fun d(v: Int) = Ui.dp(this, v)
    private fun prefs() = getSharedPreferences("alih", MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.INK
        window.navigationBarColor = Ui.INK

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.INK)
            setPadding(d(20), d(44), d(20), d(14))
        }

        root.addView(TextView(this).apply {
            text = "VarDeX"
            textSize = 30f
            setTextColor(Ui.PAPER)
            typeface = Typeface.SERIF
            setPadding(0, 0, 0, d(14))
        })

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Tempel", "Terminal", "Bulatan").forEachIndexed { i, n ->
            tabs.addView(tab(n, i), LinearLayout.LayoutParams(-2, -2).apply { marginEnd = d(6) })
        }
        root.addView(tabs)
        root.addView(View(this).apply { setBackgroundColor(Ui.LINE) },
            LinearLayout.LayoutParams(-1, d(1)))

        pages = listOf(PasteView(this), Terminal(this), bubblePage())
        pages.forEach { root.addView(it, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = d(14) }) }

        setContentView(root)
        select(prefs().getInt("tab", 0))
    }

    private fun tab(label: String, i: Int) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val t = TextView(this@MainActivity).apply {
            text = label.uppercase()
            typeface = Typeface.MONOSPACE
            textSize = 12.5f
            letterSpacing = 0.1f
            gravity = Gravity.CENTER
            setPadding(d(12), d(10), d(12), d(10))
        }
        val u = View(this@MainActivity)
        tabText.add(t)
        tabLine.add(u)
        addView(t)
        addView(u, LinearLayout.LayoutParams(-1, d(2)))
        setOnClickListener { select(i) }
    }

    private fun select(i: Int) {
        prefs().edit().putInt("tab", i).apply()
        pages.forEachIndexed { k, v -> v.visibility = if (k == i) View.VISIBLE else View.GONE }
        tabText.forEachIndexed { k, t -> t.setTextColor(if (k == i) Ui.PAPER else Ui.MUTED) }
        tabLine.forEachIndexed { k, u -> u.setBackgroundColor(if (k == i) Ui.AMBER else 0) }
    }

    private fun bubblePage() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(0, d(4), 0, 0)

        addView(Ui.label(this@MainActivity, "Terjemah layar"))
        addView(TextView(this@MainActivity).apply {
            text = "Bulatan V melayang di atas app lain. Buka komik, ketuk bulatan, " +
                "nyalakan Terjemah layar, lalu scroll. Hasil muncul sekitar setengah detik " +
                "setelah scroll berhenti."
            textSize = 14f
            setTextColor(Ui.PAPER)
            setLineSpacing(0f, 1.2f)
            setPadding(0, d(8), 0, d(20))
        })

        addView(Ui.label(this@MainActivity, "Bahasa asal"))
        lang = Ui.button(this@MainActivity, "", false) { pickLang() }
        addView(lang, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = d(6)
            bottomMargin = d(20)
        })

        grant = Ui.button(this@MainActivity, "Beri izin layar mengambang", false) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        addView(grant, LinearLayout.LayoutParams(-1, -2))

        toggle = Ui.button(this@MainActivity, "", true) { onToggle() }
        addView(toggle, LinearLayout.LayoutParams(-1, -2))

        addView(TextView(this@MainActivity).apply {
            text = "Model bahasa diunduh sekali, setelah itu bisa offline. " +
                "Jangan uninstall saat update, pasang saja di atas versi lama."
            textSize = 12f
            setTextColor(Ui.MUTED)
            setPadding(0, d(20), 0, 0)
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val ok = Settings.canDrawOverlays(this)
        grant.visibility = if (ok) View.GONE else View.VISIBLE
        toggle.visibility = if (ok) View.VISIBLE else View.GONE
        toggle.text = if (FloatService.running) "Hentikan bulatan" else "Mulai bulatan"
        lang.text = Langs.name(prefs().getString("src", Langs.DEFAULT)!!) + "  ▾"
    }

    private fun pickLang() {
        val tags = Langs.all()
        AlertDialog.Builder(this)
            .setTitle("Bahasa asal komik")
            .setItems(tags.map { Langs.name(it) }.toTypedArray()) { _, i ->
                prefs().edit().putString("src", tags[i]).apply()
                refresh()
            }
            .show()
    }

    private fun onToggle() {
        if (FloatService.running) {
            stopService(Intent(this, FloatService::class.java))
            FloatService.running = false
            refresh()
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, FloatService::class.java)
                    .putExtra(FloatService.EXTRA_CODE, resultCode)
                    .putExtra(FloatService.EXTRA_DATA, data)
            )
            FloatService.running = true
        }
        refresh()
    }
}
